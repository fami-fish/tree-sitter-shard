const PREC = {
  paren: 16,
  calls: 15,
  /* ++ and -- (post)
   * .  array index
   * -> member access
   * { } struct/array declaration
   */
  postfix: 14,
  /* ++ and -- (pre)
   * unary - and +
   * ~ logical NOT
   * ~~ bitwize NOT
   * & adress of
   * size <shit>
   */
  prefix: 13,
  multiplicative: 12,
  additive: 11,
  bitshift: 10,
  relational: 9,
  equality: 8,
  bitand: 7,
  bitxor: 6,
  bitor: 5,
  logical_and: 4,
  logical_xor: 3,
  logical_or: 2,
  assignment: 1,
};

module.exports = grammar({
  name: "shard",

  extras: ($) => [/ |\t|\r/, $.comment],
  rules: {
    /* STATEMENT \n
     * STATEMENT \n
     * STATEMENT \n
     * STATEMENT \n
     * \n? ^D
     */

    /* STATEMENT ^D
     */

    program: ($) =>
      seq(
        $.statement,
        repeat(seq($.statement, repeat1("\n"))),
        optional($.statement),
      ),

    statement: ($) => prec(2, choice($.literal, $.expr, $.ident)),
    expr: ($) =>
      choice(
        $.literal,
        $.ident,

        prec.left(PREC.multiplicative, binary_op($, "*")),
        prec.left(PREC.additive, binary_op($, "-")),
        prec.left(PREC.additive, binary_op($, "+")),
      ),

    literal: ($) => choice($.float, $.int),
    ident: () => /[a-zA-Z_][a-zA-Z0-9_]+/,
    float: () => /-?[0-9][0-9_]*\.[0-9][0-9_]*/,
    int: () =>
      choice(/-?[0-9][0-9_]*/, /0x[0-9a-fA-F][0-9a-fA-F]*/, /0b[01][01_]*/),

    comment: () =>
      choice(seq("//", /.*/), seq("/*", /[^*]*\*+([^/*][^*]*\*+)*/, "/")),
  },
});

function binary_op($, op) {
  seq($.expr, op, $.expr);
}
